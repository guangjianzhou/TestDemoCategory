//
//  HZLocation.m
//  areapicker
//
//  Created by 谈宇刚 on 15/11/9.
//  Copyright © 2015年 tanyugang. All rights reserved.
//

#import "TYGLocation.h"

@implementation TYGLocation

@end
