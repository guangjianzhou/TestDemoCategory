//
//  StylingViewController.h
//  RETableViewManagerExample
//
//  Created by Roman Efimov on 6/13/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ControlsViewController.h"

@interface StylingViewController : ControlsViewController <RETableViewManagerDelegate>

@end
