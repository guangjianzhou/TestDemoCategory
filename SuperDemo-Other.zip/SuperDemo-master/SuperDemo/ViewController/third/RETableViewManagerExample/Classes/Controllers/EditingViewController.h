//
//  EditingViewController.h
//  RETableViewManagerExample
//
//  Created by Roman Efimov on 4/13/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RETableViewManager/RETableViewManager.h>

@interface EditingViewController : UITableViewController <UIAlertViewDelegate>

@end
