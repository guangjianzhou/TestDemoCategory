//
//  TYGStarRationViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/5/4.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  星星评分器

#import <UIKit/UIKit.h>

@interface TYGStarRationViewController : UIViewController

@end
