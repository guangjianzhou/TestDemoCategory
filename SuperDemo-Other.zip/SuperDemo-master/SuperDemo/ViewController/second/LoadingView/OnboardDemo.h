//
//  OnboardDemo.h
//  SuperDemo
//
//  Created by 谈宇刚 on 15/9/1.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnboardDemo : UIViewController

- (IBAction)buttonClick:(UIButton *)sender;

@end
