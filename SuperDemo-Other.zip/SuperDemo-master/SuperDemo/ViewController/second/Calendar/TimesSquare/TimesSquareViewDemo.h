//
//  TimesSquareViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/7/28.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimesSquareViewDemo : UITabBarController

@end
