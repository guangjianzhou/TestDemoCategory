//
//  LDProgressViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/7/24.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  实现扁平化风格或者或者非扁平化风格的ProgressView，可以给ProgressView添加动态条纹背景

#import <UIKit/UIKit.h>

@interface LDProgressViewController : UIViewController

@end
