//
//  ReadingListViewController.h
//  iOS7Sampler
//
//  Created by shuichi on 10/2/13.
//  Copyright (c) 2013 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReadingListViewController : UIViewController

@end
