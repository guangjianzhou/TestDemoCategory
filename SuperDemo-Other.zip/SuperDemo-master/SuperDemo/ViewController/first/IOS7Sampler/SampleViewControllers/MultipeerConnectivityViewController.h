//
//  MultipeerConnectivityViewController.h
//  iOS7Sampler
//
//  Created by Andrew Frederick on 9/27/13.
//  Copyright (c) 2013 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultipeerConnectivityViewController : UIViewController

@end
