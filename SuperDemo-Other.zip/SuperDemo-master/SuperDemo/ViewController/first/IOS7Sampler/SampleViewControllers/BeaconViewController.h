//
//  BeaconViewController.h
//  iOS7Sampler
//
//  Created by shuichi on 12/5/13.
//  Copyright (c) 2013 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeaconViewController : UIViewController

@end
