//
//  AwesomeMenuDemoViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/7/14.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AwesomeMenu.h"

@interface AwesomeMenuDemoViewController : UIViewController<AwesomeMenuDelegate>

@end
