//
//  ViewController.h
//  AutomobileMarket
//
//  Created by tanyugang on 15/3/11.
//  Copyright (c) 2015年 YDAPP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UITabBarController

@property (strong, nonatomic) UINavigationController *navBarController1;
@property (strong, nonatomic) UINavigationController *navBarController2;
@property (strong, nonatomic) UINavigationController *navBarController3;
@property (strong, nonatomic) UINavigationController *navBarController4;

@end

