//
//  TYGIBViewController.h
//  SuperDemo
//
//  Created by 谈宇刚 on 15/8/18.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  IBInspectable

#import <UIKit/UIKit.h>

@interface TYGIBViewController : UIViewController

@end
