//
//  TYGValidViewController.h
//  SuperDemo
//
//  Created by 谈宇刚 on 15/9/11.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  正则验证

#import <UIKit/UIKit.h>

@interface TYGValidViewController : UIViewController

@end
